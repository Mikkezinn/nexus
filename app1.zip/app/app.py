from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Configuração do banco de dados PostgreSQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@database-aula-cloud.cuebxlhckhcy.us-east-1.rds.amazonaws.com:5432/postgres' 
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Desativa notificações de modificações no banco
db = SQLAlchemy(app)

# Definindo o modelo da tabela 'teste'
class Tabela(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    item = db.Column(db.String(120), nullable=False)

# Rota para exibir o formulário e inserir dados
@app.route('/', methods=['GET', 'POST'])
def index():
    # Criando as tabelas na primeira execução
    db.create_all()
    
    if request.method == 'POST':
        new_item = request.form.get('item')
        if new_item:
            # Inserindo dados na tabela 'teste'
            db.session.add(Tabela(item=new_item))
            db.session.commit()
        return redirect(url_for('index'))
    
    return render_template('index.html', items=None)

# Rota para consulta dos dados na tabela 'teste'
@app.route('/game', methods=['GET'])
def consulta():
    # Consulta e exibe todos os dados da tabela 'teste'
    items = Tabela.query.all()
    return render_template('index.html', items=items)

if __name__ == '__main__':
    app.run(debug=True)
